<template>
    <div class="auth">
        Ini page register
    </div>
</template>

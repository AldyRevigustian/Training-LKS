<template>
    <p>Ini halaman admin</p>
</template>
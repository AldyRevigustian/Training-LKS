<template>
    <div class="card">
        <slot></slot>
    </div>    
</template>
<style lang="scss">
    .card {
        border: 1px solid #ccc;
        padding: 1rem;
        border-radius: .5rem;
        margin-bottom: 1rem;
    }
</style>

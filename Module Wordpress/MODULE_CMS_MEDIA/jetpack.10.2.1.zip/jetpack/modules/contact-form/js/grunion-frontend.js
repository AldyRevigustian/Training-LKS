jQuery( function ( $ ) {
	$( '.contact-form input.jp-contact-form-date' ).datepicker();
} );

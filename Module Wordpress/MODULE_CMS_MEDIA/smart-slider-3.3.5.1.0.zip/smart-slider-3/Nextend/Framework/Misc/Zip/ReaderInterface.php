<?php

namespace Nextend\Framework\Misc\Zip;


interface ReaderInterface {

    public function read($path);
}
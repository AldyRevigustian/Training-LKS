<?php


namespace Nextend\Framework\Browse\BulletProof;


class Exception extends \Exception {

}